<?php include "header.php"?>
    <div class="container">
        <h3 class="text-center"><?=$text?></h3>
    </div>
    <div class="container">
        <a href="<?=base_url()?>">Doties uz sākumlapu</a>
    </div>

<?php include "footer.php"?>