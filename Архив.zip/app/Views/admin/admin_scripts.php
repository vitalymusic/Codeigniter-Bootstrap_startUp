<script>
$(document).ready(()=>{
    $('.delbtn').click((e)=>{
        if(confirm("Tiešām izdzēst?")){
            id = e.target.dataset.id;
            $.get("<?= base_url()?>/deleteApp/"+id,function(data){
                location.reload();
        })
        
            }
        
    })
    
})
</script>