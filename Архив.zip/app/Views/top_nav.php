<nav class="navbar navbar-dark bg-primary">
  <div class="container-md">
    <a class="navbar-brand" href="<?=base_url()?>"><img src="https://rsmt.lv/wp-content/themes/RSMPV/img/logo.svg" alt="" style="height:50px"></a>
  </div>
</nav>